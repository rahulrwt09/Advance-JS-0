import { navbar } from "./navbar.js";
let navbar_div = document.getElementById('navbar');
navbar_div.innerHTML=navbar();