import { navbar } from "./navbar.js";
let navbar_div = document.getElementById('navbar');
navbar_div.innerHTML=navbar();

//81f936bed3b044066369361a5764b79f

//add event handeler for post_create button 

let create_btn= document.getElementById('create_btn')
create_btn.onclick=()=>{
    //submitting post to localserver
    createPost();
};

//add event handeler for select file input
let inp_image= document.getElementById('image')
inp_image.onchange= ()=>{
   handelimage();

}
let img_url;

const handelimage= async ()=>{
    //access to the image data 
    let img =document.getElementById('image');
    let actual_img = img.files[0]
    console.log('actual_img', actual_img)
    let form = new FormData();
    form.append('image',actual_img)
    //make a post request 
     let res = await fetch(`https://api.imgbb.com/1/upload?key=81f936bed3b044066369361a5764b79f`,
     { 
     method:'POST',
     body:form,
    });
    let data = await res.json()
    console.log(data);
     img_url= data.data.display_url;
     };

   const createPost = async()=>{
    let id = document.getElementById('id').value;
    let caption = document.getElementById('caption').value;
     //store all data in obj 
     let send_this_data= {
        id,
        caption,
        img_url,
     };
    let res= await fetch('http://localhost:3000/posts', {
        method:'POST',
        body:JSON.stringify(send_this_data),
        headers:{
          'Content-type':'application/json',
          
        },

    });
     let  data= await res.json();
     console.log(data)
   }

  


 
