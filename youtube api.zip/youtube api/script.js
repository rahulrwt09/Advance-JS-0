

//'https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&q=surfing&key=[YOUR_API_KEY]' \


//
// AIzaSyAYtmZlXz9qThK_JR8X2DIeN-FA46Y1Zrg
// Accept: application/json


const searchvideo=  async()=>{

    try{
        const apikey  = 'AIzaSyCbv03W1H47UuU39RT61qe_uhSWyiFLE2M'
        let  search_term= document.getElementById("search_term").value;
        console.log(search_term)
        let response= await fetch(`https://youtube.googleapis.com/youtube/v3/search?part=snippet&maxREsult=25&q=${search_term}&key=${apikey}`);
           
        
        let data= await response.json();

        let actual_data= data.items; 
        console.log(actual_data);
        appendvideo(actual_data);
    }
    catch(err){
       console.log(err);
    }




};
const conatiner= document.getElementById('container');

const appendvideo= (data)=>{
    conatiner.innerHTML=null
      data.forEach(({snippet}) => {
         let div= document.createElement("div");
         
         let title= document.createElement('p');
         title.innerText=snippet.title

         
         let channel_title =document.createElement('p');
         channel_title.innerText=snippet.channelTitle


         let thumbnail =document.createElement('img')
         thumbnail.src=snippet.thumbnails.high.url;


         div.append(thumbnail,title,channel_title)
         conatiner.append(div);
      });
};