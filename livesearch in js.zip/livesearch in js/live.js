let slider1 = document.getElementById("slider");
    function slider(){
         


let images= [`https://img1.hotstarext.com/image/upload/f_auto,t_web_m_1x/sources/r1/cms/prod/9286/1449286-h-bc76ea4a87b7`,
            `https://img1.hotstarext.com/image/upload/f_auto,t_web_m_1x/sources/r1/cms/prod/4292/754292-h`,
            `https://img1.hotstarext.com/image/upload/f_auto,t_web_m_1x/sources/r1/cms/prod/2742/1462742-h-825f30cb8681`, 
]

let imgElement= document.createElement(`img`);
let i=0
setInterval(function(){
    if(i===images.length){
      i=0;
    }
    imgElement.src = images[i];
    slider1.append(imgElement);
    i++
   
}, 3000);
    }
    slider();
/*   ---------------------- SLIDER KA KAAM KAHTAM --------------*/

/*------------- SEARCH MOVIES FUNCTION FROM ONCLICK ---------------*/ 
async function searchMovies(){
 
   let loder= document.getElementById("loder");
   loder.style.display="block";
   let movie_name= document.getElementById("movie_name").value;
 /*
response.then(function(success)
{ 
    let data = success.json();
   data.then(function(success){
       console.log(success.Search);
   })
   data.catch(function(error){
    console.log(error);
   })
})
response.catch (function (error) {
    console.log(error);
})
*/
try{
let response= await fetch(`http://www.omdbapi.com/?apikey=481dfc16&s=${movie_name}`)
let data = await response.json();
let actual_data= data.Search;
console.log(actual_data)

 appendmovie(actual_data)
}

catch(err){
  console.log(err);
}
}

// title poster year 

function appendmovie(actual_data){
    
   let loder= document.getElementById("loder");
   loder.style.display="none";
    

    let movie_div= document.getElementById("container");
       
    movie_div.innerHTML=null;
    actual_data.forEach(function(el) {
      
         let div = document.createElement("div");
 
       
  
         let poster= document.createElement("img");
         console.log(el.poster)
         poster.src=el.Poster;
         
         let title= document.createElement("h2");
         title.innerText=el.Title;
         
         let type= document.createElement("h3");
         type.innerText=el.Type;
  
         let year= document.createElement("h4");
        year.innerText=el.Year;
  
         let imdbID= document.createElement("h5");
         imdbID.innerText=el.imdbID;
  
        
      
  
  
       
  
         div.append(poster,title, type,year,imdbID)
         movie_div.append(div);
        
        
    });


}
let id;
function debounce(func,delay){
    if(id){
        clearTimeout(id)


    }
    id=setTimeout(function()
    {
        func()
    }, delay
    );

}